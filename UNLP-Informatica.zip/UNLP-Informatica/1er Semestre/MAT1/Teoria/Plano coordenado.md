# Plano coordenado

```functionplot
---
title: Plano Coordenado
xLabel: X
yLabel: Y
bounds: [-10,10,-10,10]
disableZoom: true
grid: true
---
```
