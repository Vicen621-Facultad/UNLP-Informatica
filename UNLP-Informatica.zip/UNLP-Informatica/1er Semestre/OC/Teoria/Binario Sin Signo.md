---
isSystem: true
negativos: No puede
rango: $[0...+(2^{n-1)}]$
abreviatura: BSS
---
# Binario Sin Signo

Rango: $[0 ... +(2^{n-1})]$

Ejemplo con 4 bits:

Rango: [0...15]
Resolución: 1

$4_{10}=0100_2=0*2^3+1*2^2+0*2^1+0*2^0$