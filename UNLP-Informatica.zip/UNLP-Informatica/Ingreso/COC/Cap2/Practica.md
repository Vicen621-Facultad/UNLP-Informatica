# COC | Practica capitulo 2

1.
   1. 01010101 AND 01010101 = 01010101
   2. 01010101 AND 10101010 = 00000000
   3. 11110000 AND 11111111 = 11110000
   4. 01010101 OR 01010101 = 01010101
   5. 01010101 OR 10101010 = 11111111
   6. 11110001 OR 11110010 = 11110011
   7. 01010101 XOR 01010101 = 00000000
   8. 01010101 XOR 10101010 = 11111111
   9. 00001111 XOR 00000000 = 00001111
   10. NOT 11111111 = 00000000
   11. NOT 01000000 = 10111111
   12. NOT 00001110 = 11110001
2. | Dato | Op. Logica | Mask | = | Resultado |
   |--|--|--|--|--|
   | D<sub>7</sub>D<sub>6</sub>D<sub>5</sub>D<sub>4</sub>D<sub>3</sub>D<sub>2</sub>D<sub>1</sub>D<sub>0</sub> | OR | 11100111 | = | 111D<sub>4</sub>D<sub>3</sub>111 |
   | D<sub>7</sub>D<sub>6</sub>D<sub>5</sub>D<sub>4</sub>D<sub>3</sub>D<sub>2</sub>D<sub>1</sub>D<sub>0</sub> | OR | 00001000 | = | D<sub>7</sub>D<sub>6</sub>D<sub>5</sub>D<sub>4</sub>**1**D<sub>2</sub>D<sub>1</sub>D<sub>0</sub> |
   | D<sub>7</sub>D<sub>6</sub>D<sub>5</sub>D<sub>4</sub>D<sub>3</sub>D<sub>2</sub>D<sub>1</sub>D<sub>0</sub> | AND | 01111111 | = | **0**D<sub>6</sub>D<sub>5</sub>D<sub>4</sub>D<sub>3</sub>D<sub>2</sub>D<sub>1</sub>D<sub>0</sub> |
   | D<sub>7</sub>D<sub>6</sub>D<sub>5</sub>D<sub>4</sub>D<sub>3</sub>D<sub>2</sub>D<sub>1</sub>D<sub>0</sub> | XOR | 01010000 | = | D<sub>7</sub>(Ḏ<sub>6</sub>)D<sub>5</sub>(Ḏ<sub>4</sub>)D<sub>3</sub>D<sub>2</sub>D<sub>1</sub>D<sub>0</sub> |
3.
   1.
4.
   1. Si, es posible
   2. NOT: ![NOT-gate](https://cdn.discordapp.com/attachments/861110403156017172/1026258576882290739/unknown.png)

      AND: ![AND-gate](https://cdn.discordapp.com/attachments/861110403156017172/1026259533250699284/unknown.png)

      OR: ![OR-gate](https://cdn.discordapp.com/attachments/861110403156017172/1026259973224812595/unknown.png)
