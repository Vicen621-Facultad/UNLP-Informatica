# COC | Teoria capitulo 2

1. La razon tecnica de esto es que al las computadoras ser sistemas electronicos, la manera mas facil de consumir informacion es por medio de ver si hay energia o no (0 ó 1).
2. Puede llegar a conducir a errores si el codificador de numeros decimales o hexadecimales a binario no esta bien hecho. Pero si esta bien hecho no deberia haber ningun error, simplemente un retraso en la ejecucion ya que tiene que hacer la conversion y eso llevaria tiempo.
3. La ventaja que tiene esto es que al ser una unidad propia la que hace las operaciones de punto flotante, esta está diseñada especificamente para eso por ende el tiempo de ejecucion de la misma es menor a si lo hace la unidad ALU de un CPU.
4. La utilidad que tendria es que el usuario podria hacer sus propias compuertas logicas y asi poder lograr el resultado que este buscando. Si existen y se llaman Circuitos Logicos Programables (PLC)
5. El funcionamiento de ese ciruito acepta 3 entradas y devuelve 8 salidas. Se justifica el nombre ya que lo que hace es desde una entrada de 3 bits, devuelve una salisa de 8 bits.
