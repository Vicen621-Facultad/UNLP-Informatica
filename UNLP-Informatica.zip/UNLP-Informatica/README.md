<h1 align="center"> 💻 Licenciatura en Analisis de Sistemas - UNLP </h1>
<div align="center">
<img src="https://media.giphy.com/media/1C8bHHJturSx2/giphy.gif"/>
 </div>
<br>

<h2 align="center">📝 Materias</h2>

%% TODO: Pasar apuntes de MAT1 acá %%

| Materia                                                                            | Inicio Cursada | Finalización Cursada | Nota final |
| ---------------------------------------------------------------------------------- | -------------- |:-------------------- |:---------- |
| [COC](https://github.com/vicen621/UNLP-Informatica/tree/main/Ingreso/COC)          | 12-09-2022     | 02-12-2022           | 9          |
| [EPA](https://github.com/vicen621/UNLP-Informatica/tree/main/Ingreso/EPA)          | 12-09-2022     | 02-12-2022           | 9          |
| [MAT0](https://github.com/vicen621/UNLP-Informatica/tree/main/Ingreso/MAT0)        | 12-09-2022     | 30-01-2023           | 10         |
| [OC](https://github.com/vicen621/UNLP-Informatica/tree/main/1er%20Semestre/OC)     | 20-03-2023     | -                    | -          |
| [CADP](https://github.com/vicen621/UNLP-Informatica/tree/main/1er%20Semestre/CADP) | 20-03-2023     | -                    | -          |
| [MAT1](https://github.com/vicen621/UNLP-Informatica/tree/main/1er%20Semestre/MAT1) | 20-03-2023     | -                    | -          |